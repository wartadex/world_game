export const firebaseConfig = {
  apiKey: "AIzaSyDVmzb5zPjTADG_uOUw641hZITvMKjcge4",
  authDomain: "where-in-the-world-game.firebaseapp.com",
  projectId: "where-in-the-world-game",
  storageBucket: "where-in-the-world-game.appspot.com",
  messagingSenderId: "304834358530",
  appId: "1:304834358530:web:90d892309ef104dde5661b",
  measurementId: "G-LT1C38389Q",
};
