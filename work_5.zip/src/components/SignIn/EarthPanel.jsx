export default function EarthPanel() {
  return (
    <div className="bg-lightGray lg:flex justify-center items-center hidden">
      <img src="images/earth.png" width="400" alt="earth" />
    </div>
  )
}