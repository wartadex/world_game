export function isThemeDark() {
  return localStorage.getItem("theme") == "false"
}